import React from 'react'
import Navbar from './components/Navbar'
import UserDetail from './components/UserDetail'
import AgeDetails from './components/ageDetail'

function App() {
  return (
    <>
    <Navbar />
    <UserDetail />
    <AgeDetails />
    </>
  )
}

export default App