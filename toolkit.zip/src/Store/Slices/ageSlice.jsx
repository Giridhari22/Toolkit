import { createSlice } from "@reduxjs/toolkit";

const ageSlice = createSlice({
  name: "ageSlice",
  initialState: [], // Corrected typo here
  reducers: {
    // this is a func or let say it is a micro reducer...helps to get data and send data to and from frontend
    addAge(state, action) {
      // bas last m data add karta jayega jo new data aayega
      state.push(action.payload)
      console.log(action.payload);
    },
    removeAge(state, action) {
      console.log("hii"+ action.payload)
      // ab hame data ko delete karna h id ko pa k
      // by using splice method , we have to pass which data we want to delete and how many data u want to delete
     state.splice(action.payload,1)
    },
    clearAllAge(state, action){
      console.log("hii clear all")
      return [];//return empty array matlb ki jitne v value the inke sabko khali kr dia
    },
  },
});

console.log(ageSlice.actions);
export const { addAge, removeAge, clearAllAge } = ageSlice.actions;
export default ageSlice.reducer;
