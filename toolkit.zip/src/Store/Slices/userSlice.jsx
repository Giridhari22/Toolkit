import { createSlice } from "@reduxjs/toolkit";


const userSlice = createSlice({
  name: "userSlice",
  initialState: [], // Corrected typo here
  reducers: {
    // this is a func or let say it is a micro reducer...helps to get data and send data to and from frontend
    addUser(state, action) {
      // bas last m data add karta jayega jo new data aayega
      state.push(action.payload)
      console.log(action.payload);
    },
    removeUser(state, action) {
      console.log("hii"+ action.payload)
      // ab hame data ko delete karna h id ko pa k
      // by using splice method , we have to pass which data we want to delete and how many data u want to delete
     state.splice(action.payload,1)
    },
    clearAllUsers(state, action){
      console.log("hii delete all")
      return [];//return empty array matlb ki jitne v value the inke sabko khali kr dia
    },
  },
});

console.log(userSlice.actions);
export const { addUser, removeUser, clearAllUsers } = userSlice.actions;
export default userSlice.reducer;
