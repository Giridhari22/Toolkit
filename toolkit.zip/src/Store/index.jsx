import { configureStore } from "@reduxjs/toolkit";
import userSlice from "./Slices/userSlice";
import ageSlice from "./Slices/ageSlice";

const store = configureStore({
    reducer:{
        users:userSlice,
        age:ageSlice
    },
})

export default store ;