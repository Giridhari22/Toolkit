import Chance from "chance";
const chance = Chance();
// chance is used to make fake data  for testing

export const fakeuserData = ()=>{
    console.log(chance.name({ middle: true }));
    return chance.name({ middle: true });
}


export const fakeAgeData = ()=>{
    console.log(chance.age({type: 'child'}));
    return chance.age({type: 'child'});
}