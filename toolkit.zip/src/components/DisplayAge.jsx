import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import styled from 'styled-components'
import { MdDeleteForever } from "react-icons/md";

import { removeAge } from '../Store/Slices/ageSlice';

const DisplayAge = () => {

    const dispatch = useDispatch()
    const data = useSelector((state) => {
        return state.age;
    });

    
    console.log({ data });


    const deleteAge = (id)=>{
        // ye removeUser ....userSlice se aa rkha hai ..aur ham uss microreducer ko call krte hai
        dispatch(removeAge(id))
    }
    return (
        <Wrapper>
            {data.map((user, id) => (
                <li key={id}>
                    <span>{user}</span>
                    <button className='btn-delete'  onClick={()=>deleteAge(id)}>
                        <MdDeleteForever className="delete-icon" />
                    </button>
                </li>
            ))}
        </Wrapper>
    );
};

const Wrapper = styled.section`
    margin: 1rem 3.2rem;

    li {
        list-style-type: none !important;
        display: flex;
        justify-content: space-between;
        align-items: center; /* Center vertically */
    }

    h3 {
        margin: 0;
    }

    .admin-table {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
        margin: 4rem 0;
    }

    .admin-subtitle {
        font-size: 3.2rem;
    }

    .btn-delete {
        background-color: transparent;
        border: none;
    }

    .delete-icon {
        font-size: 2.6rem;
        color: #f12711;
        filter: drop-shadow(0.2rem 0.2rem 0.5rem rgb(255 0 0 / 0.2));
        cursor: pointer;
    }

    @media screen and (max-width: 998px) {
        .admin-subtitle {
            margin-bottom: 1.6rem;
        }
    }
`;

export default DisplayAge;
