import React from "react";
import styled from "styled-components";
import { fakeAgeData } from "../api";
import { useDispatch } from "react-redux";
import DisplayAge from "./DisplayAge";
import { addAge } from "../Store/Slices/ageSlice";
import DeleteAllUsers from "./DeleteAllUsers";

// useDispatch jo hai mini reducer ko call krne k kam aata hai slice se

const AgeDetails = () => {
const  dispatch = useDispatch()
  const addNewAge = (payload)=>{
    // ye dispatch k under payload k rup m addUser()-{jo ki microreducer hai} usko mangwaya gaya hai
    dispatch(addAge(payload))
    console.log({payload})


  }


    return (
        <Wrapper>
            <div className="content">
                <div className="admin-table">
                    <div className="admin-subtitle">List of Age Details</div>
                    <button className="btn add-btn" onClick={()=>addNewAge(fakeAgeData())}>Add New Age</button>
                </div>
                <ul>
                    <DisplayAge />
                </ul>
                <hr />
                <DeleteAllUsers />
            </div>
        </Wrapper>
    );
};


// this is the new way to write css of same file by wrapper method
const Wrapper = styled.section`
  margin: 1rem 3.2rem;

  .content ul {
    list-style-type: none !important;
    display: flex;
    flex-direction: column;
  }

  h3 {
    margin: 0;
  }

  .admin-table {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    margin: 4rem 0;
  }

  .admin-subtitle {
    font-size: 3.2rem;
  }

  .delete-btn {
    background-color: transparent;
    border: none;
  }

  .delete-icon {
    font-size: 2.6rem;
    color: #f12711;
    filter: drop-shadow(0.2rem 0.2rem 0.5rem rgb(255 0 0 / 0.2));
    cursor: pointer;
  }
  @media screen and (max-width: 998px) {
    .admin-subtitle {
      margin-bottom: 1.6rem;
    }
  }
`;

export default AgeDetails;